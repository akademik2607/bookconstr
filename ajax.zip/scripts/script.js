"use strict";
//change cover or pages
const coverOrPages = () => {
    const AD = document.getElementById('AD'),
        workarea = document.querySelector('.workarea'),
        toPager = document.querySelector('.toPager'),
        toCover = document.querySelector('.toCover');

    toPager.addEventListener('click', () => {
        workarea.classList.remove('cover-edit');
        AD.classList.remove('hidePager');
    });

    toCover.addEventListener('click', () => {
        workarea.classList.add('cover-edit');
        AD.classList.add('hidePager');
    });

};

coverOrPages();

//print prints

const printPrints = () => {
    const printPickerList = document.querySelector('.printPickerList'),
        printBackground = document.querySelector('.print-background');

    printPickerList.addEventListener('click', (event) => {
        let target = event.target;
        while(!target.classList.contains('img')){
            if(target.classList.contains('printPickerList')) return;
            target = target.parentNode;
            
        }
        printBackground.style.backgroundImage = target.style.backgroundImage;
    });
};
printPrints();

//change textur
const changeTextur = () => {
    const colorPicker = document.querySelector('.color-picker'),
        typeDropDown = document.querySelector('.type-picker .type-dropdown');
        
    const changeActive = (event, par) =>{
        const target = event.target;
        if(target.tagName.toLowerCase() !== 'li') return;

        const list = par.querySelectorAll('li');
        list.forEach((item) => {
            item.classList.remove('active');
            if(item === target){
                item.classList.add('active');
            }
        });
        console.log(list);

        const activeColor = colorPicker.querySelector('.active'),
        activeType = typeDropDown.querySelector('.active');
    const textur = {
        color_id: activeColor.dataset.id,
        type_id: activeType.dataset.id
    };

    const textJson = JSON.stringify(textur);
    console.log(textJson);

    fetch('../ajax/ajax.php', {
        method: 'POST',
        body: textJson,
        headers: {
            "Content-Type": "application/json;charset=utf-8"
        }
        
    }).then((response) => {
        return response.text();
    }).then((result) => {
        console.log(JSON.parse(result)[0][0]);  
        const coverBackArr = JSON.parse(result),
             
            coverBackground = document.querySelector('.cover-background');
            coverBackground.style.backgroundImage = 'url(./texturs/' + coverBackArr[0][0] + ')';
            console.log(coverBackground.style.backgroundImage);

    });
    };

    colorPicker.addEventListener('click', 
        (event) => changeActive(event, colorPicker));

    typeDropDown.addEventListener('click', 
        (event) => changeActive(event, typeDropDown));
        console.log(colorPicker);
    
};

changeTextur();

//upload photo popup
const photoPopup = () =>{
    const uploadPhotoPopup = document.getElementById('UploadPhotoPopup'),
        aLoadPhoto = document.querySelector('.a-load-photo');
    aLoadPhoto.addEventListener('click', (event) =>{
        event.preventDefault();
        uploadPhotoPopup.classList.remove('mfp-hide');
    });
};
photoPopup();

//pager slider

const changePagerSlider = () => {
    const pagerSlider = document.querySelector('.pager-slider'),
        slides = pagerSlider.querySelectorAll('.page');
    pagerSlider.addEventListener('click', (event) => {
        let target = event.target;
        while(!target.classList.contains('page')){
            if(target.classList.contains('pager-slider')) return;
            target = target.parentNode;
        }
        slides.forEach((item) => {
            item.classList.remove('active');
        });
        target.classList.add('active');
    });
};

changePagerSlider();
